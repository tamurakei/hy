	<footer class="fadeIn">
		<div>
		<ul>
			<?php /*
			<a href="https://twitter.com/share" data-url="http://healthy-yummy.com" data-count="none"><li><span class="icon-twitter"></span></li></a>
			<a href="http://www.facebook.com/share.php?u=http://healthy-yummy.com" target="_blank"><li><span class="icon-facebook"></span></li></a>
			
			<a href="#"><i class="fa fa-instagram"></i></a>
			*/ ?>
			
		</ul>
		<div class="clearfix"></div>
		&copy; 2016 healthy & Yummy
		</div>
	</footer>
</div><!--wrap-->
	<?php wp_footer(); ?>
</body>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
</html>