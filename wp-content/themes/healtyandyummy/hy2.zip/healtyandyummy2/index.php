<?php get_header(); ?>

	
	<div class="articleWrap">
		<div class="article">
			<div class="articleTitle">
				<h2></h2>
			</div>
			<div class="articleTxt">
				<p>
					
				</p>
			</div>
		</div>
		<div class="articleFadeU"></div>
		<div class="articleFadeB"></div>
		<div class="clearfix"></div>
		</div></div>
			
<?php get_footer(); ?>