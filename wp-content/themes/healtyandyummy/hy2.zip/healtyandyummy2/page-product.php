<?php get_header(); ?>
<?php include (TEMPLATEPATH . '/loop-product.php') ?>
<?php get_footer(); ?>
